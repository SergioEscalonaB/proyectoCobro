import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Prisma, Cliente } from '@prisma/client'; 

@Injectable()
export class ClienteService {
  constructor(private prisma: PrismaService) {}

  // Función auxiliar para obtener el saldo pendiente de una tarjeta
  private getSaldoPendiente(tarjeta: any): number {
    // Si hay descripciones, toma el desResta de la última descripción
    if (tarjeta.descripciones && tarjeta.descripciones.length > 0) {
      return tarjeta.descripciones[0].desResta;
    }
    // Si no hay descripciones (tarjeta recién creada), el saldo es el valor inicial
    return tarjeta.tarValor;
  }

  // Obtener todos los clientes
  async obtenerClientes() {
    const clientes = await this.prisma.cliente.findMany({
      include: { 
        tarjetas: {
          where: { estado: 'Activa' }, // Solo tarjetas activas
          include: {
            descripciones: {
              orderBy: {
                desFecha: 'desc'
              },
              take: 1
            }
          },
          orderBy: {
            iten: 'asc' // Ordenar las tarjetas por iten para asegurar que la primera es la que define el orden
          }
        }, 
        cobro: true 
      },
    });

    // Calcular saldo total por cliente y determinar estado
    const clientesConSaldo = clientes.map(cliente => {
      // Encontrar la tarjeta activa (si existe)
      const tarjetaActiva = cliente.tarjetas.find(t => t.estado === 'Activa');

      let saldoTotal = 0;
      let iten = Infinity; // Usar Infinity para que los inactivos vayan al final

      if (tarjetaActiva) {
        saldoTotal = this.getSaldoPendiente(tarjetaActiva);
        iten = tarjetaActiva.iten;
      }

      // Determinar estado basado en saldo total
      const estado = saldoTotal > 0 ? 'Activo' : 'Inactivo';

      return {
        ...cliente,
        estado, // Sobrescribir el estado basado en saldo
        saldoTotal,
        iten, // Campo temporal para ordenamiento
        // Se adjunta la información de la tarjeta activa si existe
        tarjetaActiva: tarjetaActiva ? {
            ...tarjetaActiva,
            saldoActual: saldoTotal
        } : null
      };
    });

    // Ordenar los clientes por el iten de su tarjeta activa
    return clientesConSaldo.sort((a, b) => a.iten - b.iten);
  }


  // --- LÓGICA CENTRAL DE INSERCIÓN DE TARJETA CON RE-INDEXACIÓN (ITEN) ---
  /**
   * Lógica para calcular el nuevo iten y realizar la re-indexación.
   * Se ejecuta dentro de una transacción.
   * @param tx - La instancia de Prisma Transaction
   * @param data - Datos de la tarjeta a crear
   * @param insertarPosicion - { referencia: number, modo: 'antes' | 'despues' } (opcional)
   * @returns El nuevo iten para la tarjeta
   */
  private async calcularYReindexarIten(
    tx: Prisma.TransactionClient,
    insertarPosicion?: { referencia: number; modo: 'antes' | 'despues' }
  ): Promise<number> {
    // --- 1. Si no hay posicion especial, se asigna al final ---
    if (!insertarPosicion) {
      const maxIten = await tx.tarjeta.aggregate({
        _max: { iten: true },
        where: { estado: 'Activa' },
      });
      return (maxIten._max.iten || 0) + 1;
    }

    // --- 2. Si se quiere insertar antes o después de otra tarjeta ---
    const { referencia, modo } = insertarPosicion;

    // Buscar la tarjeta de referencia
    const tarjetaRef = await tx.tarjeta.findFirst({
      where: { iten: referencia, estado: 'Activa' },
    });

    if (!tarjetaRef) {
      throw new BadRequestException(`No existe una tarjeta activa con iten ${referencia} para usar como referencia.`);
    }

    // Determinar el nuevo iten y el punto de inicio de la re-indexación
    const nuevoIten = modo === 'antes' ? tarjetaRef.iten : tarjetaRef.iten + 1;
    const itenToShift = nuevoIten; // El punto de inicio es el nuevo iten

    // Desplazar hacia abajo todas las tarjetas activas a partir de ese punto
    await tx.tarjeta.updateMany({
      where: {
        estado: 'Activa',
        iten: { gte: itenToShift },
      },
      data: { iten: { increment: 1 } },
    });

    return nuevoIten;
  }
  // -----------------------------------------------------------------------


  // Crear cliente y tarjeta inicial
  async crearCliente(data: any, insertarPosicion?: { referencia: number; modo: 'antes' | 'despues' }) {
    const {
      cliCodigo,
      cliNombre,
      cliCalle,
      cobCodigo,
      tarValor,
      tiempo,
      fp,
      tarFecha,
    } = data;

    // Usar transacción para asegurar atomicidad en la creación y re-indexación
    return this.prisma.$transaction(async (tx) => {
      // VALIDACIÓN 1: No permitir crear clientes si ya existe por cliCodigo
      const clienteExistente = await tx.cliente.findUnique({
        where: { cliCodigo: Number(cliCodigo) },
        include: {
          tarjetas: {
            where: { estado: 'Activa' }, // Solo tarjetas activas
            include: {
              descripciones: {
                orderBy: { desFecha: 'desc' },
                take: 1
              }
            }
          }
        }
      });

      // Aseguramos que nuevoCliente sea del tipo Cliente (sin las relaciones)
      let nuevoCliente: Cliente | null = clienteExistente ? clienteExistente as Cliente : null;

      if (clienteExistente) {
        // Si el cliente existe, verificamos si tiene saldo pendiente
        const tarjetaActiva = clienteExistente.tarjetas[0]; // Solo habrá una activa por la lógica de negocio
        
        if (tarjetaActiva) {
            const saldoActual = this.getSaldoPendiente(tarjetaActiva);
            
            if (saldoActual > 0) {
                // Cliente ya tiene préstamo activo
                throw new BadRequestException(
                    `El cliente "${clienteExistente.cliNombre}" con cedula ${cliCodigo} ya existe y tiene una tarjeta activa con saldo pendiente de $${saldoActual}.`
                );
            }
        }
        
        // Si el cliente existe, pero no tiene tarjeta activa o saldo pendiente, se crea una nueva tarjeta
        // Mantenemos la lógica original: si existe y saldo es 0, crea la tarjeta.
      }

      // Logica de cálculo de cuotas
      let diasFrecuencia = 1;
      switch (fp) {
        case 'Semanal':
          diasFrecuencia = 7;
          break;
        case 'Quincenal':
          diasFrecuencia = 15;
          break;
        case 'Mensual':
          diasFrecuencia = 30;
          break;
        case 'Diario':
        default:
          diasFrecuencia = 1;
          break;
      }
      const numCuotas = Math.ceil(Number(tiempo) / diasFrecuencia);
      const tarCuota = Number((Number(tarValor) / numCuotas).toFixed(2));
      // ---------------------------------------------------------------------

      // --- 1. Calcular el nuevo iten y re-indexar si es necesario ---
      const nuevoIten = await this.calcularYReindexarIten(tx, insertarPosicion);

      if (!clienteExistente) {
        // El cliente NO existe, se procede a crear el cliente
        // Verificar si el cobrador existe
        const cobradorExistente = await tx.cobro.findUnique({
          where: { cobCodigo },
        });

        if (!cobradorExistente) {
          throw new BadRequestException(`El cobrador ${cobCodigo} no existe`);
        }

        // Crear nuevo cliente
        nuevoCliente = await tx.cliente.create({
          data: {
            cliCodigo: Number(cliCodigo),
            cliNombre,
            cliCalle,
            cobCodigo,
            estado: 'Activo',
          },
        });
      }

      // --- 2. Crear tarjeta con el iten calculado ---
      const nuevaTarjeta = await tx.tarjeta.create({
        data: {
          tarCodigo: `TAR-${cliCodigo}-${Date.now()}`,
          tarValor: Number(tarValor),
          tarCuota,
          tarFecha: tarFecha ? new Date(tarFecha) : new Date(),
          iten: nuevoIten, // ¡El nuevo iten!
          estado: 'Activa',
          clavo: false,
          tiempo: Number(tiempo),
          fp,
          cliCodigo: Number(cliCodigo),
        },
      });

      // --- 3. Crear descripción inicial ---
      await tx.descripcion.create({
        data: {
          desFecha: new Date(),
          desAbono: 0,
          desResta: nuevaTarjeta.tarValor,
          fechaAct: new Date(),
          tarCodigo: nuevaTarjeta.tarCodigo,
        },
      });

      // --- 4. Asegurar que el cliente esté activo ---
      if (nuevoCliente && nuevoCliente.estado !== 'Activo') {
        await tx.cliente.update({
          where: { cliCodigo: Number(cliCodigo) },
          data: { estado: 'Activo' },
        });
      }

      return {
        mensaje: clienteExistente 
          ? 'Cliente existente con saldo 0, nueva tarjeta creada exitosamente' 
          : 'Cliente y tarjeta creados exitosamente',
        nuevoCliente: nuevoCliente,
        tarjeta: nuevaTarjeta,
        calculo: {
          frecuencia: fp,
          diasFrecuencia,
          numCuotas,
          tarCuota,
        },
      };
    });
  }


  // Crear tarjeta para un cliente existente (reactivación)
  async crearTarjetaParaClienteExistente(data: any, insertarPosicion?: { referencia: number; modo: 'antes' | 'despues' }) {
    const { cliCodigo, tarValor, tiempo, fp, tarFecha } = data;

    // Usar transacción para asegurar atomicidad en la creación y re-indexación
    return this.prisma.$transaction(async (tx) => {
      // Buscar cliente existente con sus tarjetas activas
      const cliente = await tx.cliente.findUnique({
        where: { cliCodigo: Number(cliCodigo) },
        include: { 
          tarjetas: { 
            where: { estado: 'Activa' }, // Solo tarjetas activas
            include: { descripciones: { orderBy: { desFecha: 'desc' }, take: 1 } } 
          } 
        },
      });

      if (!cliente) {
        throw new NotFoundException(`Cliente con código ${cliCodigo} no encontrado.`);
      }

      // Validar si ya tiene saldo pendiente
      const tarjetaActiva = cliente.tarjetas[0];
      if (tarjetaActiva) {
        const saldoActual = this.getSaldoPendiente(tarjetaActiva);
        if (saldoActual > 0) {
          throw new BadRequestException(
            `El cliente "${cliente.cliNombre}" ya tiene una tarjeta activa con saldo pendiente de $${saldoActual}.`
          );
        }
      }

      // --- Lógica de cálculo de cuotas ---
      let diasFrecuencia = 1;
      switch (fp) {
        case 'Semanal':
          diasFrecuencia = 7;
          break;
        case 'Quincenal':
          diasFrecuencia = 15;
          break;
        case 'Mensual':
          diasFrecuencia = 30;
          break;
        case 'Diario':
        default:
          diasFrecuencia = 1;
          break;
      }
      const numCuotas = Math.ceil(Number(tiempo) / diasFrecuencia);
      const tarCuota = Number((Number(tarValor) / numCuotas).toFixed(2));
      // ------------------------------------

      // --- 1. Calcular el nuevo iten y re-indexar si es necesario ---
      const nuevoIten = await this.calcularYReindexarIten(tx, insertarPosicion);

      // --- 2. Crear tarjeta con el iten calculado ---
      const nuevaTarjeta = await tx.tarjeta.create({
        data: {
          tarCodigo: `TAR-${cliCodigo}-${Date.now()}`,
          tarValor: Number(tarValor),
          tarCuota,
          tarFecha: tarFecha ? new Date(tarFecha) : new Date(),
          iten: nuevoIten, // ¡El nuevo iten!
          estado: 'Activa',
          clavo: false,
          tiempo: Number(tiempo),
          fp,
          cliCodigo: Number(cliCodigo),
        },
      });

      // --- 3. Crear descripción inicial ---
      await tx.descripcion.create({
        data: {
          desFecha: new Date(),
          desAbono: 0,
          desResta: nuevaTarjeta.tarValor,
          fechaAct: new Date(),
          tarCodigo: nuevaTarjeta.tarCodigo,
        },
      });

      // --- 4. Reactivar cliente si estaba inactivo ---
      if (cliente.estado !== 'Activo') {
        await tx.cliente.update({
          where: { cliCodigo: Number(cliCodigo) },
          data: { estado: 'Activo' },
        });
      }

      return {
        mensaje: 'Nueva tarjeta creada exitosamente para cliente existente',
        nuevaTarjeta,
      };
    });
  }


  // Obtener cliente por código
  async obtenerClientePorCodigo(cliCodigo: string) {
    const cliente = await this.prisma.cliente.findUnique({
      where: { cliCodigo: Number(cliCodigo) },
      include: {
        tarjetas: {
          include: {
            descripciones: {
              orderBy: {
                desFecha: 'desc'
              },
              take: 1
            }
          }
        },
        cobro: true
      },
    });

    if (!cliente) {
      throw new NotFoundException('Cliente no encontrado');
    }

    // Calcular saldo total por cliente y determinar estado
    const tarjetaActiva = cliente.tarjetas.find(t => t.estado === 'Activa');
    let saldoTotal = 0;
    if (tarjetaActiva) {
      saldoTotal = this.getSaldoPendiente(tarjetaActiva);
    }

    const estado = saldoTotal > 0 ? 'Activo' : 'Inactivo';

    return {
      ...cliente,
      estado,
      saldoTotal,
      tarjetaActiva: tarjetaActiva ? {
        ...tarjetaActiva,
        saldoActual: saldoTotal
      } : null
    };
  }

  // "Eliminar" cliente (solo si saldo = 0)
  async eliminarCliente(cliCodigo: string) {
    const cliente = await this.prisma.cliente.findUnique({
      where: { cliCodigo: Number(cliCodigo) },
      include: { 
        tarjetas: { 
          where: { estado: 'Activa' }, 
          include: {
            descripciones: {
              orderBy: { desFecha: 'desc' },
              take: 1
            }
          }
        } 
      },
    });

    if (!cliente) {
      throw new NotFoundException('Cliente no encontrado');
    }

    // Calcular saldo total basado en la tarjeta activa
    const tarjetaActiva = cliente.tarjetas[0];
    let saldoTotal = 0;

    if (tarjetaActiva) {
      saldoTotal = this.getSaldoPendiente(tarjetaActiva);
    }

    if (saldoTotal > 0) {
      throw new BadRequestException(
        'No se puede eliminar cliente con saldo pendiente.',
      );
    }

    // Si el cliente tiene una tarjeta activa con saldo 0, se debe "desactivar" la tarjeta
    // y re-indexar la lista de cobro.
    
    // Si no tiene tarjeta activa, simplemente se marca el cliente como inactivo.
    if (tarjetaActiva) {
      // Usar transacción para desactivar la tarjeta y re-indexar
      return this.prisma.$transaction(async (tx) => {
        // 1. Obtener el iten de la tarjeta a desactivar
        const itenADesactivar = tarjetaActiva.iten;

        // 2. Desactivar la tarjeta (y quitar el iten)
        await tx.tarjeta.update({
          where: { tarCodigo: tarjetaActiva.tarCodigo },
          data: { 
            estado: 'Pagada', // O el estado que uses para tarjetas terminadas
            iten: 0, // Resetear iten
          },
        });

        // 3. Re-indexar: Mover hacia arriba todas las tarjetas con iten > itenADesactivar
        await tx.tarjeta.updateMany({
          where: {
            estado: 'Activa', // Solo tarjetas activas
            iten: { gt: itenADesactivar },
          },
          data: { iten: { decrement: 1 } },
        });

        // 4. Marcar cliente como Inactivo
        return tx.cliente.update({
          where: { cliCodigo: Number(cliCodigo) },
          data: { estado: 'Inactivo' },
        });
      });
    } else {
      // En lugar de borrar, se marca como inactivo
      return this.prisma.cliente.update({
        where: { cliCodigo: Number(cliCodigo) },
        data: { estado: 'Inactivo' },
      });
    }
  }

  // Permitir modificar datos básicos
  async actualizarCliente(cliCodigo: string, data: any) {
    return this.prisma.cliente.update({
      where: { cliCodigo: Number(cliCodigo) },
      data,
    });
  }

  // Método adicional: Obtener estado real del cliente basado en saldo
  async obtenerEstadoReal(cliCodigo: string) {
    const cliente = await this.prisma.cliente.findUnique({
      where: { cliCodigo: Number(cliCodigo) },
      include: { 
        tarjetas: { 
          where: { estado: 'Activa' }, 
          include: {
            descripciones: {
              orderBy: { desFecha: 'desc' },
              take: 1
            }
          }
        } 
      },
    });

    if (!cliente) {
      throw new NotFoundException('Cliente no encontrado');
    }

    // Calcular saldo total
    const tarjetaActiva = cliente.tarjetas[0];
    let saldoTotal = 0;

    if (tarjetaActiva) {
      saldoTotal = this.getSaldoPendiente(tarjetaActiva);
    }

    const estadoReal = saldoTotal > 0 ? 'Activo' : 'Inactivo';

    // Si el estado en BD no coincide con el estado real, actualizarlo
    if (cliente.estado !== estadoReal) {
      await this.prisma.cliente.update({
        where: { cliCodigo: Number(cliCodigo) },
        data: { estado: estadoReal },
      });
    }

    return {
      cliente: {
        ...cliente,
        estado: estadoReal
      },
      saldoTotal,
      estadoReal
    };
  }

  // Método Peligroso: Elimina cliente, tarjetas y descripciones. SIN verificación de saldo.
  async eliminarClientePeligroso(cliCodigo: string) {
    const cliente = await this.prisma.cliente.findUnique({
      where: { cliCodigo: Number(cliCodigo) },
      include: {
        tarjetas: true // Incluir todas las tarjetas para saber si había una activa
      }
    });

    if (!cliente) {
      throw new NotFoundException('Cliente no encontrado');
    }

    // Identificar la tarjeta activa para re-indexación
    const tarjetaActiva = cliente.tarjetas.find(t => t.estado === 'Activa');

    // Usar transacción para asegurar que todas las eliminaciones se hagan o ninguna
    return await this.prisma.$transaction(async (tx) => {
      // 1Eliminar descripciones de todas las tarjetas del cliente
      for (const tarjeta of cliente.tarjetas) {
        await tx.descripcion.deleteMany({
          where: { tarCodigo: tarjeta.tarCodigo }
        });
      }
      // 2. Eliminar todas las tarjetas del cliente
      await tx.tarjeta.deleteMany({
        where: { cliCodigo: Number(cliCodigo) }
      });
      // 3. Eliminar cliente
      const clienteEliminado = await tx.cliente.delete({
        where: { cliCodigo: Number(cliCodigo) }
      });
      // 4. Re-indexar la lista de cobro si se eliminó una tarjeta activa
      if (tarjetaActiva) {
        // Mover hacia arriba todas las tarjetas con iten > iten de la tarjeta eliminada
        await tx.tarjeta.updateMany({
          where: {
            estado: 'Activa', // Solo tarjetas activas
            iten: { gt: tarjetaActiva.iten },
          },
          data: { iten: { decrement: 1 } },
        });
      }

      return {
        mensaje: 'Cliente, tarjetas y descripciones eliminados completamente de la base de datos (Operación Peligrosa).',
        clienteEliminado,
      };
    });
  }
}
