import { Controller, Get, Post, Body, Delete, Param, Put, Query } from '@nestjs/common';
import { ClienteService } from './cliente.service';

@Controller('clientes')
export class ClienteController {
  constructor(private readonly clienteService: ClienteService) {}

  // Obtener todos los clientes
  @Get()
  obtenerClientes() {
    return this.clienteService.obtenerClientes();
  }

  // Crear cliente nuevo (con tarjeta inicial obligatoria)
  // Permite especificar la posición de la nueva tarjeta en la ruta de cobro.
  // Ejemplo: POST /clientes?referencia=10&modo=antes
  @Post()
  crearCliente(
    @Body() data: any,
    @Query('referencia') referencia?: string,
    @Query('modo') modo?: 'antes' | 'despues',
  ) {
    if (referencia && modo) {
      return this.clienteService.crearCliente(data, {
        referencia: Number(referencia),
        modo,
      });
    }
    return this.clienteService.crearCliente(data);
  }

  // Actualizar datos básicos del cliente
  @Put(':cliCodigo')
  actualizarCliente(@Param('cliCodigo') cliCodigo: string, @Body() data: any) {
    return this.clienteService.actualizarCliente(cliCodigo, data);
  }

  // Eliminar cliente (solo si su saldo es 0)
  @Delete(':cliCodigo')
  eliminarCliente(@Param('cliCodigo') cliCodigo: string) {
    return this.clienteService.eliminarCliente(cliCodigo);
  }

  // Obtener estado real del cliente (verifica saldo y lo sincroniza)
  @Get(':cliCodigo/estado-real')
  obtenerEstadoReal(@Param('cliCodigo') cliCodigo: string) {
    return this.clienteService.obtenerEstadoReal(cliCodigo);
  }

  // Ruta oculta y peligrosa para eliminación total. (PELIGROSO)
  @Delete('peligro-eliminar-cliente/:cliCodigo')
  eliminarClientePeligroso(@Param('cliCodigo') cliCodigo: string) {
    return this.clienteService.eliminarClientePeligroso(cliCodigo);
  }

  // Crear una nueva tarjeta para un cliente existente (reactivación)
  // Permite especificar la posición de la nueva tarjeta en la ruta de cobro.
  // Ejemplo: POST /clientes/12345/nuevatarjeta?referencia=10&modo=antes
  @Post(':cliCodigo/nuevatarjeta')
  crearTarjetaParaClienteExistente(
    @Param('cliCodigo') cliCodigo: string,
    @Body() data: any,
    @Query('referencia') referencia?: string,
    @Query('modo') modo?: 'antes' | 'despues',
  ) {
    const insertarPosicion = (referencia && modo) ? {
      referencia: Number(referencia),
      modo,
    } : undefined;

    return this.clienteService.crearTarjetaParaClienteExistente({
      ...data,
      cliCodigo,
    }, insertarPosicion);
  }
}
